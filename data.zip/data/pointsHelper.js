const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'points.json');

// تحميل النقاط من الملف
function loadPoints() {
  try {
    if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '{}');
    return JSON.parse(fs.readFileSync(filePath));
  } catch (err) {
    console.error('❌ خطأ أثناء تحميل النقاط:', err);
    return {};
  }
}

// حفظ النقاط في الملف
function savePoints(data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('❌ خطأ أثناء حفظ النقاط:', err);
  }
}

// إضافة نقاط للمستخدم
function addPoints(jid, amount = 1) {
  const points = loadPoints();
  points[jid] = (points[jid] || 0) + amount;
  savePoints(points);
}

// الحصول على نقاط المستخدم
function getPoints(jid) {
  const points = loadPoints();
  return points[jid] || 0;
}

module.exports = {
  addPoints,
  getPoints
};