const fetch = require("node-fetch");
const sharp = require("sharp");

module.exports = {
  command: "موت",
  description: "فلتر WASTED على صورة الشخص",
  usage: ".موت @user",
  category: "ترفيه",

  async execute(sock, msg) {
    try {
      const jid = msg.key.remoteJid;

      const mentions =
        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

      if (!mentions.length) {
        return sock.sendMessage(jid, {
          text: "منشن شخص عشان أعمله WASTED 💀"
        }, { quoted: msg });
      }

      const target = mentions[0];

      let pfp;
      try {
        pfp = await sock.profilePictureUrl(target, "image");
      } catch {
        return sock.sendMessage(jid, {
          text: "ما قدرت أجيب صورة البروفايل 😢"
        }, { quoted: msg });
      }

      const imgBuffer = await (await fetch(pfp)).buffer();

      // صورة WASTED PNG شفافة (تقدر تغيّرها)
      const wastedUrl = "https://i.imgur.com/3Q9QZ3v.png";
      const wastedBuffer = await (await fetch(wastedUrl)).buffer();

      const result = await sharp(imgBuffer)
        .resize(512, 512)
        .composite([
          {
            input: wastedBuffer,
            gravity: "center"
          }
        ])
        .modulate({
          brightness: 0.5,
          saturation: 0.2
        })
        .png()
        .toBuffer();

      await sock.sendMessage(jid, {
        image: result,
        caption: `💀 WASTED @${target.split("@")[0]}`,
        mentions: [target]
      }, { quoted: msg });

    } catch (err) {
      console.error(err);
    }
  }
};