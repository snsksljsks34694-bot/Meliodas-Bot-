const fs = require('fs');
const path = require('path');
const { eliteNumbers } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

const copiedGroups = {};

module.exports = {
    command: ['نسخة', 'نسخ', 'copy-group'],
    description: 'نسخ القروب أو حذفه أو لصقه في قروب آخر',
    usage: '.نسخة [نسخ/حذف/لصق]',
    category: 'DEVELOPER',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = decode(msg.key.participant || chatId);
            const senderNum = sender.split('@')[0];

            if (!eliteNumbers.includes(senderNum)) {
                return await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | منع  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ ❌ هذا الأمر للنخبة فقط
⌗━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });
            }

            if (!chatId.endsWith('@g.us')) {
                return await sock.sendMessage(chatId, {
                    text: '❌ هذا الأمر يعمل داخل المجموعات فقط.'
                }, { quoted: msg });
            }

            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = body.trim().split(' ').slice(1);
            const action = args[0]?.toLowerCase();

            if (!action || action === 'مساعدة' || action === 'help') {
                return await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | نسخة القروب  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ .نسخة نسخ   → نسخ بيانات القروب الحالي
◈ .نسخة حذف   → حذف بيانات القروب المنسوخة
◈ .نسخة لصق   → لصق البيانات في هذا القروب
◈ .نسخة عرض   → عرض البيانات المنسوخة
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });
            }

            if (action === 'نسخ' || action === 'copy') {
                const meta = await sock.groupMetadata(chatId);
                copiedGroups[senderNum] = {
                    subject: meta.subject,
                    description: meta.desc || '',
                    participants: meta.participants.map(p => p.id),
                    announce: meta.announce,
                    restrict: meta.restrict,
                    copiedAt: new Date().toLocaleString('ar')
                };

                return await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | نسخ ✅  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ ✅ تم نسخ بيانات القروب!
◈ 📋 الاسم: ${meta.subject}
◈ 👥 الأعضاء: ${meta.participants.length}
◈ 📝 الوصف: ${(meta.desc || 'لا يوجد').slice(0, 50)}
◈ 💡 الآن اذهب للقروب المستهدف واكتب .نسخة لصق
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });
            }

            if (action === 'حذف' || action === 'delete') {
                if (!copiedGroups[senderNum]) {
                    return await sock.sendMessage(chatId, {
                        text: '❌ لا يوجد قروب منسوخ حاليًا!'
                    }, { quoted: msg });
                }
                delete copiedGroups[senderNum];
                return await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | حذف ✅  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ 🗑️ تم حذف بيانات القروب المنسوخة
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });
            }

            if (action === 'لصق' || action === 'paste') {
                const copied = copiedGroups[senderNum];
                if (!copied) {
                    return await sock.sendMessage(chatId, {
                        text: '❌ لم تقم بنسخ أي قروب! استخدم .نسخة نسخ أولاً.'
                    }, { quoted: msg });
                }

                await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | لصق 🔄  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ جاري تطبيق بيانات القروب المنسوخ...
◈ 📋 الاسم: ${copied.subject}
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });

                try { await sock.groupUpdateSubject(chatId, copied.subject).catch(() => {}); } catch {}
                try { if (copied.description) await sock.groupUpdateDescription(chatId, copied.description).catch(() => {}); } catch {}

                const chunks = [];
                const pArr = copied.participants;
                for (let i = 0; i < pArr.length; i += 15) chunks.push(pArr.slice(i, i + 15));
                for (const chunk of chunks) {
                    await sock.groupParticipantsUpdate(chatId, chunk, 'add').catch(() => {});
                    await new Promise(r => setTimeout(r, 500));
                }

                return await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | اكتمل ✅  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ ✅ تم لصق بيانات القروب بنجاح!
◈ 📋 الاسم: ${copied.subject}
◈ 👥 الأعضاء المضافة: ${copied.participants.length}
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });
            }

            if (action === 'عرض' || action === 'show') {
                const copied = copiedGroups[senderNum];
                if (!copied) return await sock.sendMessage(chatId, { text: '❌ لا يوجد قروب منسوخ.' }, { quoted: msg });
                return await sock.sendMessage(chatId, {
                    text: `
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
┊  ❄️ The Frost | البيانات  ┊
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗
◈ 📋 الاسم: ${copied.subject}
◈ 👥 الأعضاء: ${copied.participants.length}
◈ 📝 الوصف: ${(copied.description || 'لا يوجد').slice(0, 100)}
◈ 🕒 وقت النسخ: ${copied.copiedAt}
⌗━━━━━━━━━━━━━━━━━━━━━━━━━━━━⌗`
                }, { quoted: msg });
            }

        } catch (error) {
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ خطأ: ${error.message}`
            }, { quoted: msg });
        }
    }
};
