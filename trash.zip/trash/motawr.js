const fs = require('fs');
const { join } = require('path');

// ✅ تعريف بيانات المطور (داخل الملف فقط)
global.owner = [
  [', 'The Frost☄', true],
];

module.exports = {
  command: 'المطور',
  description: 'عرض معلومات المطور مع جهة الاتصال',
  usage: '.المطور',
  category: 'info',

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;

      // بيانات المطور
      const [devId, devName] = global.owner[0];
      const devTitle = '*The Frost ❄️*';
      const devCountry = 'العالم🌍';
      const devAge = 'قد الدنيا ';
      const devNumber = `+${devId}`;
      const waLink = `https://wa.me/${devId}`;
      const devVideoPath = join(process.cwd(), 'midoriya.mp4');

      // الرسالة النصية
      const infoMessage = `
┏━━━━━━ ⬣
┃ ❄️ *معلومات The Frost* ❄️
┃ 
┃ ✯ الاسم: ${devTitle}
┃ ✯ اللقب: *The Frost ❄️*
┃ ✯ الدولة: ${devCountry}
┃ ✯ العمر: ${devAge}
┃ ✯ الرقم: ${devNumber}
┗━━━━━━ ⬣
📌 للتواصل عبر واتساب:
${waLink}
      `.trim();

      // زر واتساب داخل نفس الرسالة
      const buttons = [
        {
          index: 0,
          urlButton: {
            displayText: '📨 راسلني عبر واتساب',
            url: waLink,
          },
        }
      ];

      // إرسال الرسالة (فيديو أو نص)
      if (fs.existsSync(devVideoPath)) {
        const videoBuffer = fs.readFileSync(devVideoPath);
        await sock.sendMessage(chatId, {
          video: videoBuffer,
          caption: infoMessage,
          footer: '𝓜𝓮𝓵𝓲𝓸𝓭𝓪𝓼 𝒉𝒂𝒔 𝒂𝒓𝒓𝒊𝒗𝒆𝒅 ❄️',
          buttons: buttons,
          headerType: 5
        }, { quoted: msg });
      } else {
        await sock.sendMessage(chatId, {
          text: infoMessage,
          footer: '𝓜𝓮𝓵𝓲𝓸𝓭𝓪𝓼 𝒉𝒂𝒔 𝒂𝒓𝒓𝒊𝒗𝒆𝒅 ❄️',
          buttons: buttons,
          headerType: 1
        }, { quoted: msg });
      }

      // ✅ إرسال جهة الاتصال (vCard)
      const vcard = `
BEGIN:VCARD
VERSION:3.0
FN: The Frost ❄️
TEL;type=CELL;type=VOICE;waid=+966570740414
EMAIL:croco@ashura.com
NOTE:هذا رقم شخصي، لا ترسل أوامر!
END:VCARD
      `.trim();

      await sock.sendMessage(chatId, {
        contacts: {
          displayName: 'The Frost ❄️',
          contacts: [{ vcard }]
        }
      }, { quoted: msg });

    } catch (err) {
      console.error('❌ خطأ في أمر المطور:', err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حدث خطأ أثناء عرض معلومات المطور:\n${err.message || err.toString()}`,
      }, { quoted: msg });
    }
  },
};
