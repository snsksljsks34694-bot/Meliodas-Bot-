// *حقوق مطور شادو  🛡*
// 📄 *سكس.js* (جزء 1/1):

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports = {
  command: 'سكس-هات',
  description: 'يبعتلك ملصق وصوت سكس جامد 😂',
  category: 'ترفيه',

  async execute(sock, m) {
    try {
      const links = [
        'https://telegra.ph/file/2040e9308fd62a13c3988.jpg',
        // زوّد صور هنا لو حبيت 😈
      ];

      const imageUrl = links[Math.floor(Math.random() * links.length)];
      const inputPath = path.join(process.cwd(), 'sks.jpg');
      const outputPath = path.join(process.cwd(), 'sks.webp');

      // 1️⃣ الرد بالكلام الأول
      await sock.sendMessage(m.key.remoteJid, {
        text: 'خود يا كسمك السكس اهو 💦'
      }, { quoted: m });

      // 2️⃣ تحميل الصورة وتحويلها إلى ملصق
      const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      fs.writeFileSync(inputPath, Buffer.from(response.data));

      exec(`ffmpeg -i ${inputPath} -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v libwebp -preset default -quality 100 -compression_level 6 -qscale 50 ${outputPath}`, async (error) => {
        if (error) {
          console.error('❌ ffmpeg error:', error);
          return await sock.sendMessage(m.key.remoteJid, {
            text: '❌ حصل خطأ في تحويل الصورة لستيكر.'
          }, { quoted: m });
        }

        const webpBuffer = fs.readFileSync(outputPath);
        await sock.sendMessage(m.key.remoteJid, {
          sticker: webpBuffer
        }, { quoted: m });

        // 🧹 تنظيف
        fs.unlinkSync(inputPath);
        fs.unlinkSync(outputPath);

        // 3️⃣ إرسال الصوت بعد ما يبعت الملصق
        const audioPath = '/sdcard/.bot/bot/sounds/sks.mp3';
        if (fs.existsSync(audioPath)) {
          await sock.sendMessage(m.key.remoteJid, {
            audio: fs.readFileSync(audioPath),
            mimetype: 'audio/mp4',
            ptt: true
          }, { quoted: m });
        }
      });

    } catch (err) {
      console.error('❌ Error in .سكس:', err);
      await sock.sendMessage(m.key.remoteJid, {
        text: '❌ حصلت مشكلة يسطا جرب تاني.'
      }, { quoted: m });
    }
  }
};