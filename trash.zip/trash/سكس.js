const path = require('path');

module.exports = {
  command: 'سكس',
  description: '🎥 عرض فيديو ثم صوت عند الحضور',
  category: 'fun',

  async execute(sock, msg) {
    const jid = msg.key.remoteJid;

    // المسارات الكاملة للملفات
    const videoPath = path.join(__dirname, '../resources/لأ.mp4');
    const audioPath = path.join(__dirname, '../resources/لأ.m4a');

    try {
      // إرسال الفيديو أولاً
      await sock.sendMessage(jid, {
        video: { url: videoPath },
        caption: 
        
   `❄️ *The Frost ⊰𝐁𝐎𝐓* ❄️ 
❄️ من ورا لأ يعور..❄️`
        
        
      }, { quoted: msg });

      // بعده مباشرةً إرسال الصوت
      await sock.sendMessage(jid, {
        audio: { url: audioPath },
        mimetype: 'audio/mpeg', // أو audio/mp4 حسب نوع m4a
        ptt: false
      });

    } catch (err) {
      console.error('✗✗ خطأ في أمر حضورر:', err);
      await sock.sendMessage(jid, {
        text: '❌ حصل خطأ أثناء تشغيل الحضور.',
      }, { quoted: msg });
    }
  }
};