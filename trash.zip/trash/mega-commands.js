// ❄️ The Frost - محرك الأوامر الضخم
const fs = require('fs');
const path = require('path');

const DEKU_IMG = path.join(__dirname, '../deku.jpeg');
const getImg = () => fs.existsSync(DEKU_IMG) ? fs.readFileSync(DEKU_IMG) : null;

const box = (title, lines) => {
  const w = 40;
  const top = `⌗${'━'.repeat(w)}⌗`;
  const mid = `┊  ${title.padEnd(w - 2)}┊`;
  const content = lines.map(l => `◈ ${l}`).join('\n');
  return `${top}\n${mid}\n${top}\n${content}\n${top}`;
};

const send = async (sock, msg, text) => {
  const img = getImg();
  const chatId = msg.key.remoteJid;
  if (img) {
    await sock.sendMessage(chatId, { image: img, caption: text }, { quoted: msg });
  } else {
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  }
};

// قائمة بيانات الأوامر - 700 أمر ضخم
const megaCmds = [

// ━━━━━━ فئة: متنوعة ━━━━━━
{cmd:'وقتي',cat:'tools',desc:'عرض الوقت الحالي',fn:async(s,m)=>{const n=new Date();await send(s,m,box('⏰ الوقت',['التاريخ: '+n.toLocaleDateString('ar-SA'),`الوقت: ${n.toLocaleTimeString('ar-SA')}`,`اليوم: ${n.toLocaleDateString('ar-SA',{weekday:'long'})}`]));}},
{cmd:'تاريخي',cat:'tools',desc:'التاريخ الميلادي والهجري',fn:async(s,m)=>{const n=new Date();await send(s,m,box('📅 التاريخ',['ميلادي: '+n.toLocaleDateString('ar-SA'),`هجري: ${new Intl.DateTimeFormat('ar-SA-u-ca-islamic',{dateStyle:'full'}).format(n)}`]));}},
{cmd:'برجي',cat:'fun',desc:'برجك الفلكي',fn:async(s,m)=>{const b=['الحمل♈','الثور♉','الجوزاء♊','السرطان♋','الأسد♌','العذراء♍','الميزان♊','العقرب♏','القوس♐','الجدي♑','الدلو♒','الحوت♓'];await send(s,m,box('⭐ برجك',['برجك: '+b[Math.floor(Math.random()*b.length)],'العام: 2026 🌟','حظك: ممتاز! ❄️']));}},
{cmd:'نكتة',cat:'fun',desc:'نكتة عشوائية',fn:async(s,m)=>{const j=['ليش البحر مالح؟ لأن الأسماك ما تحب يتحمم😂','شو الفرق بين الأستاذ والقطار؟ القطار يقول اتفضلوا والأستاذ يقول اجلسوا😂','شو اسم الجمل بدون حدبة؟ حظنا كله هيك😂'];await send(s,m,box('😂 نكتة',[j[Math.floor(Math.random()*j.length)]]));}},
{cmd:'حقيقة',cat:'fun',desc:'حقيقة عشوائية',fn:async(s,m)=>{const f=['النمل لا ينام أبدًا 🐜','القطط تنام 16 ساعة يوميًا 😴','البشر الوحيدون الذين يشعرون بالخجل 😊','قلب الروبيان في رأسه 🦐'];await send(s,m,box('💡 حقيقة',[f[Math.floor(Math.random()*f.length)]]));}},
{cmd:'رقم-عشوائي',cat:'fun',desc:'رقم عشوائي',fn:async(s,m)=>{const n=Math.floor(Math.random()*1000)+1;await send(s,m,box('🎲 رقم عشوائي',['الرقم: '+n,'📊 من 1 إلى 1000']));}},
{cmd:'قولي',cat:'fun',desc:'البوت يقول أي شيء',fn:async(s,m)=>{const body=m.message?.extendedTextMessage?.text||m.message?.conversation||'';const text=body.split(' ').slice(1).join(' ');await send(s,m,box('🗣️ The Frost يقول',[text||'...قل لي شيء!']));}},
{cmd:'ارسال-عشوائي',cat:'fun',desc:'رسالة تحفيزية عشوائية',fn:async(s,m)=>{const q=['لا تستسلم، النجاح قريب! 🌟','كل يوم فرصة جديدة 💪','أنت أقوى مما تظن! ❄️','المحاولة تصنع الفرق 🔥'];await send(s,m,box('✨ تحفيز',[q[Math.floor(Math.random()*q.length)]]));}},
{cmd:'اختيار',cat:'fun',desc:'اختار لك من الخيارات',fn:async(s,m)=>{const body=m.message?.extendedTextMessage?.text||m.message?.conversation||'';const parts=body.split(' ').slice(1).join(' ').split('/');const pick=parts[Math.floor(Math.random()*parts.length)];await send(s,m,box('🎯 الاختيار',['اخترت: '+(pick||'اكتب خيارات مفصولة بـ /')]));} },
{cmd:'عد',cat:'fun',desc:'عد من 1 إلى رقم',fn:async(s,m)=>{const body=m.message?.extendedTextMessage?.text||m.message?.conversation||'';const n=parseInt(body.split(' ')[1])||5;const max=Math.min(n,20);const nums=Array.from({length:max},(_,i)=>i+1).join(', ');await send(s,m,box('🔢 عدّ',[nums]));}},

// ━━━━━━ فئة: معلومات ━━━━━━
{cmd:'كم-عمري',cat:'tools',desc:'احسب عمرك',fn:async(s,m)=>{const body=m.message?.extendedTextMessage?.text||m.message?.conversation||'';const y=parseInt(body.split(' ')[1]);const age=y?2026-y:'؟';await send(s,m,box('🎂 العمر',['عمرك: '+age+' سنة','عام الميلاد: '+(y||'لم تحدد')]));}},
{cmd:'ترجم',cat:'tools',desc:'ترجمة النصوص',fn:async(s,m)=>{await send(s,m,box('🌐 الترجمة',['الترجمة غير متاحة الآن','جرب لاحقًا 😊']));}},
{cmd:'طقس',cat:'tools',desc:'حالة الطقس',fn:async(s,m)=>{await send(s,m,box('🌤️ الطقس',['الطقس: غير متاح الآن','جرب لاحقًا 😊']));}},
{cmd:'سعر-دولار',cat:'tools',desc:'سعر الدولار',fn:async(s,m)=>{await send(s,m,box('💵 الدولار',['السعر: متغير','تحقق من المصادر الرسمية 📊']));}},
{cmd:'اقتباس-يومي',cat:'tools',desc:'اقتباس اليوم',fn:async(s,m)=>{const q=['العقل زينة، والعلم سلاح 🌟','الصبر مفتاح الفرج 🔑','من جد وجد 💪','خير الكلام ما قل ودل 📖'];await send(s,m,box('💫 اقتباس اليوم',[q[Math.floor(Math.random()*q.length)]]));}},
{cmd:'تحفيز',cat:'tools',desc:'رسالة تحفيزية',fn:async(s,m)=>{const m_=m;const q=['النجاح رحلة وليس وجهة 🌟','كن التغيير الذي تريد 💪','اليوم خطوة نحو غدك الأفضل 🚀','لا تنظر للخلف إلا للاستفادة 👑'];await send(s,m_,box('⚡ تحفيز',[q[Math.floor(Math.random()*q.length)]]));}},
{cmd:'معلومة',cat:'tools',desc:'معلومة ثقافية',fn:async(s,m)=>{const f=['الصين أكبر دولة من حيث عدد السكان 🇨🇳','المملكة العربية السعودية أكبر دولة عربية 🇸🇦','المحيط الهادئ أكبر محيطات العالم 🌊','جبل إيفرست أعلى قمة في العالم ⛰️'];await send(s,m,box('📚 معلومة',[f[Math.floor(Math.random()*f.length)]]));}},
{cmd:'سؤال-ثقافي',cat:'tools',desc:'سؤال ثقافي عشوائي',fn:async(s,m)=>{const q=['ما عاصمة اليابان؟ (طوكيو)','كم عدد دول العالم؟ (195 دولة)','من أول رائد فضاء؟ (يوري غاغارين)'];await send(s,m,box('❓ سؤال ثقافي',[q[Math.floor(Math.random()*q.length)]]));}},

// ━━━━━━ فئة: ديني ━━━━━━
{cmd:'سبحان-الله',cat:'islamic',desc:'تسبيح الله',fn:async(s,m)=>{await send(s,m,box('☪️ تسبيح',['سبحان الله وبحمده','سبحان الله العظيم','لا إله إلا الله محمد رسول الله']));}},
{cmd:'آية-اليوم',cat:'islamic',desc:'آية قرآنية',fn:async(s,m)=>{const v=['﴿إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾ الشرح:6','﴿وَاللَّهُ غَالِبٌ عَلَى أَمْرِهِ﴾ يوسف:21','﴿فَإِنَّ مَعَ الْعُسْرِ يُسْرًا﴾ الشرح:5'];await send(s,m,box('📖 آية اليوم',[v[Math.floor(Math.random()*v.length)]]));}},
{cmd:'حديث-شريف',cat:'islamic',desc:'حديث نبوي شريف',fn:async(s,m)=>{const h=['«خيركم من تعلم القرآن وعلمه»','«المسلم من سلم المسلمون من لسانه ويده»','«الدين النصيحة»'];await send(s,m,box('📿 حديث شريف',[h[Math.floor(Math.random()*h.length)]]));}},
{cmd:'دعاء',cat:'islamic',desc:'دعاء مستحب',fn:async(s,m)=>{const d=['اللهم إني أسألك العافية في الدنيا والآخرة','اللهم اهدنا فيمن هديت','ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة'];await send(s,m,box('🤲 دعاء',[d[Math.floor(Math.random()*d.length)]]));}},
{cmd:'صلاة',cat:'islamic',desc:'أوقات الصلاة',fn:async(s,m)=>{await send(s,m,box('🕌 أوقات الصلاة',['الفجر: قبل الشروق','الظهر: منتصف النهار','العصر: بعد الظهر','المغرب: بعد الغروب','العشاء: الليل']));}},
{cmd:'اسماء-الله',cat:'islamic',desc:'أسماء الله الحسنى',fn:async(s,m)=>{const n=['الرحمن','الرحيم','الملك','القدوس','السلام','العزيز','الجبار','المتكبر'];const pick=n[Math.floor(Math.random()*n.length)];await send(s,m,box('✨ من أسماء الله',[pick,'سبحانه وتعالى']));}},

// ━━━━━━ فئة: ألعاب ━━━━━━
{cmd:'صراع',cat:'games',desc:'صراع بين شخصين',fn:async(s,m)=>{const r=Math.random();await send(s,m,box('⚔️ الصراع',[r>0.5?'الأول فاز! 🏆':'الثاني فاز! 🏆','نتيجة: '+(r*100).toFixed(0)+'% vs '+(100-r*100).toFixed(0)+'%']));}},
{cmd:'سباق',cat:'games',desc:'سباق عشوائي',fn:async(s,m)=>{const e=['🐇','🐢','🦊','🐎','🦁'];const w=e[Math.floor(Math.random()*e.length)];await send(s,m,box('🏁 السباق',['الفائز: '+w,'سباق السرعة: اكتمل! 🏆']));}},
{cmd:'قرعة',cat:'games',desc:'قرعة عشوائية',fn:async(s,m)=>{const body=m.message?.extendedTextMessage?.text||m.message?.conversation||'';const players=body.split(' ').slice(1);const winner=players.length?players[Math.floor(Math.random()*players.length)]:'لا يوجد لاعبون!';await send(s,m,box('🎰 القرعة',['الفائز: '+winner,'🏆 مبروك!']));}},
{cmd:'احجية',cat:'games',desc:'احجية للتخمين',fn:async(s,m)=>{const r=['ما هو الشيء الذي يُفتح دون مفتاح؟ (البيضة)','ما هو الذي له رأس وذيل بلا جسم؟ (العملة)','ما هو الذي كلما أكلت منه زاد؟ (الفهم)'];await send(s,m,box('🧩 احجية',[r[Math.floor(Math.random()*r.length)]]));}},
{cmd:'لعبة-كلمات',cat:'games',desc:'لعبة كلمات',fn:async(s,m)=>{await send(s,m,box('🎮 لعبة كلمات',['اكتب كلمة تبدأ بـ: '+['م','ب','س','ح','ع'][Math.floor(Math.random()*5)],'⏱️ عندك 30 ثانية!']));}},
{cmd:'روليت',cat:'games',desc:'روليت عشوائية',fn:async(s,m)=>{const r=Math.floor(Math.random()*6)+1;await send(s,m,box('🎡 الروليت',['الرقم: '+r,r===6?'💥 انتهى!':'✅ أمان لهذه المرة']));}},
{cmd:'طيراني',cat:'games',desc:'فيمن ستطير؟',fn:async(s,m)=>{const parts=await sock.groupMetadata?.(m.key.remoteJid).catch(()=>null);const pl=parts?.participants||[];const pick=pl.length?pl[Math.floor(Math.random()*pl.length)].id.split('@')[0]:'لا أحد';await send(s,m,box('🦅 طيران',['سيطير بـ: @'+pick]));} },
{cmd:'ثقة-النفس',cat:'games',desc:'مقياس ثقتك بنفسك',fn:async(s,m)=>{const p=Math.floor(Math.random()*100)+1;await send(s,m,box('💪 ثقة النفس',['نسبة ثقتك: '+p+'%',p>70?'أنت واثق جدًا! 🌟':p>40?'لديك إمكانات! 💡':'ثق بنفسك أكثر! 🔥']));}},
{cmd:'شجاعة',cat:'games',desc:'مقياس شجاعتك',fn:async(s,m)=>{const p=Math.floor(Math.random()*100)+1;await send(s,m,box('⚔️ الشجاعة',['نسبة شجاعتك: '+p+'%',p>70?'محارب حقيقي! 🏆':p>40?'شجاع جدًا! 💪':'قلبك طيب! 😊']));}},

// ━━━━━━ فئة: مجموعة ━━━━━━
{cmd:'اعضاء',cat:'group',desc:'عدد أعضاء المجموعة',fn:async(s,m)=>{if(!m.key.remoteJid.endsWith('@g.us'))return;const meta=await s.groupMetadata(m.key.remoteJid).catch(()=>null);await send(s,m,box('👥 الأعضاء',['المجموعة: '+(meta?.subject||'غير معروف'),'الأعضاء: '+(meta?.participants?.length||0),'المشرفون: '+(meta?.participants?.filter(p=>p.admin)?.length||0)]));}},
{cmd:'اسم-قروب',cat:'group',desc:'اسم المجموعة الحالية',fn:async(s,m)=>{if(!m.key.remoteJid.endsWith('@g.us'))return;const meta=await s.groupMetadata(m.key.remoteJid).catch(()=>null);await send(s,m,box('📌 المجموعة',['الاسم: '+(meta?.subject||'غير معروف'),'الوصف: '+((meta?.desc||'لا يوجد').slice(0,80))]));} },
{cmd:'لينك-القروب',cat:'group',desc:'لينك دعوة المجموعة',fn:async(s,m)=>{if(!m.key.remoteJid.endsWith('@g.us'))return;try{const code=await s.groupInviteCode(m.key.remoteJid);await send(s,m,box('🔗 رابط المجموعة',['https://chat.whatsapp.com/'+code]));}catch{await send(s,m,box('🔗 خطأ',['لا يمكن الحصول على الرابط الآن']));}}},
{cmd:'قفل-رسائل',cat:'group',desc:'قفل الرسائل للمشرفين فقط',fn:async(s,m)=>{if(!m.key.remoteJid.endsWith('@g.us'))return;await s.groupSettingUpdate(m.key.remoteJid,'announcement').catch(()=>{});await send(s,m,box('🔒 القفل',['تم قفل الرسائل للمشرفين فقط ✅']));} },
{cmd:'فتح-رسائل',cat:'group',desc:'فتح الرسائل للجميع',fn:async(s,m)=>{if(!m.key.remoteJid.endsWith('@g.us'))return;await s.groupSettingUpdate(m.key.remoteJid,'not_announcement').catch(()=>{});await send(s,m,box('🔓 الفتح',['تم فتح الرسائل للجميع ✅']));} },

// ━━━━━━ فئة: طرب وأغاني ━━━━━━
{cmd:'اغنية-كلمة',cat:'fun',desc:'كلمة أغنية عشوائية',fn:async(s,m)=>{const s_=['يا ليل يا عين ما أجمل السمر 🌙','أنا قلبي إليك ميال 💙','يا بنت الجيران 🌹'];await send(s,m,box('🎵 كلمات',[s_[Math.floor(Math.random()*s_.length)]]));}},
{cmd:'موسيقى',cat:'fun',desc:'نوت موسيقية عشوائية',fn:async(s,m)=>{await send(s,m,box('🎶 موسيقى',['🎵🎶🎵🎶🎵🎶','استمع لأغانيك المفضلة! 🎧']));}},

// ━━━━━━ فئة: أنمي ━━━━━━
{cmd:'انمي-عشوائي',cat:'anime',desc:'أنمي عشوائي للمشاهدة',fn:async(s,m)=>{const a=['Attack on Titan 🗡️','My Hero Academia 🦸','One Piece ⛵','Naruto 🍃','Dragon Ball ⚡','Demon Slayer ⚔️','Death Note 📓','Fullmetal Alchemist 🔩'];await send(s,m,box('🎌 أنمي عشوائي',['شاهد: '+a[Math.floor(Math.random()*a.length)],'استمتع بالمشاهدة! 🎬']));}},
{cmd:'شخصية-انمي',cat:'anime',desc:'شخصية أنمي عشوائية',fn:async(s,m)=>{const c=['ناروتو 🍃','ساسكي ⚡','غوكو ⚡','لوفي ⛵','ديكو ❄️','كيلوا ⚡','زورو ⚔️','نامي 🌊'];await send(s,m,box('👾 شخصية أنمي',['أنت مثل: '+c[Math.floor(Math.random()*c.length)]]));}},
{cmd:'قوة-انمي',cat:'anime',desc:'قوتك في عالم الأنمي',fn:async(s,m)=>{const p=['أومي (قدرات لامحدودة) ❄️','شارينغان (رؤية خارقة) 👁️','أكوما نو مي (فاكهة الشيطان) 😈','نين (طاقة حيوية) ⚡'];await send(s,m,box('💥 قوتك الأنمي',[p[Math.floor(Math.random()*p.length)]]));}},
{cmd:'بطل-انمي',cat:'anime',desc:'من أنت من أبطال الأنمي',fn:async(s,m)=>{const h=['إيزوكو The Frost ❄️','ناروتو أوزوماكي 🍃','مونكي دي لوفي ⛵','سون غوكو ⚡'];await send(s,m,box('🦸 بطلك الأنمي',['أنت: '+h[Math.floor(Math.random()*h.length)]]));}},
{cmd:'انمي-رعب',cat:'anime',desc:'أنمي رعب للمشاهدة',fn:async(s,m)=>{const a=['Another 👁️','Shiki 🧛','Higurashi 😱','Corpse Party 💀','Elfen Lied 🔪'];await send(s,m,box('😱 أنمي رعب',['شاهد: '+a[Math.floor(Math.random()*a.length)]]));} },
{cmd:'انمي-رومانسي',cat:'anime',desc:'أنمي رومانسي',fn:async(s,m)=>{const a=['Your Name 💕','Clannad 💙','Toradora 🎀','Sword Art Online ⚔️💕'];await send(s,m,box('💕 أنمي رومانسي',['شاهد: '+a[Math.floor(Math.random()*a.length)]]));} },

// ━━━━━━ فئة: The Frost خاص ━━━━━━
{cmd:'The Frost-يقول',cat:'𝕯𝖊𝖒𝖔𝖓',desc:'The Frost يقول رسالة',fn:async(s,m)=>{await send(s,m,box('❄️ The Frost يقول',['أنا هنا! The Frost 🫦','لا أحد يوقف The Frost! 💪','❄️ البرد قادم!']));} },
{cmd:'The Frost-قوي',cat:'𝕯𝖊𝖒𝖔𝖓',desc:'قوة The Frost',fn:async(s,m)=>{const p=Math.floor(Math.random()*100)+1;await send(s,m,box('💥 قوة The Frost',['قوتي: '+p*100+'%','One For All: ∞ ❄️','لا حدود لقوة The Frost!']));} },
{cmd:'The Frost-غاضب',cat:'𝕯𝖊𝖒𝖔𝖓',desc:'The Frost غاضب',fn:async(s,m)=>{await send(s,m,box('😤 The Frost غاضب!',['DETROIT SMASH! 💥','ONE FOR ALL: 100%! ⚡','لا تزعلني! ❄️🔥']));} },
{cmd:'The Frost-سعيد',cat:'𝕯𝖊𝖒𝖔𝖓',desc:'The Frost سعيد',fn:async(s,m)=>{await send(s,m,box('😊 The Frost سعيد!',['يا هلا! ❄️','أنا في قمة السعادة! 💙','شكرًا لكم! The Frost يحبكم!']));} },

// ━━━━━━ فئة: مزاح وإضحاك ━━━━━━
{cmd:'ابتسم',cat:'fun',desc:'ابتسامة The Frost',fn:async(s,m)=>{await send(s,m,box('😊 ابتسامة',['😊😄😃😁','إبتسم! الحياة جميلة ❄️','The Frost يبتسم لك!']));} },
{cmd:'ضحك',cat:'fun',desc:'The Frost يضحك',fn:async(s,m)=>{await send(s,m,box('😂 هههههه!',['HAHAHAHA! 😂','The Frost يضحك على الوضع! 😂','😂😂😂 كلها ضحك!']));} },
{cmd:'تعبير',cat:'fun',desc:'تعبير عشوائي',fn:async(s,m)=>{const e=['😂😂😂','😱😱😱','🤔🤔🤔','👏👏👏','❄️❄️❄️','💪💪💪'];await send(s,m,box('😁 تعبير',[e[Math.floor(Math.random()*e.length)]]));} },
{cmd:'ايموجي',cat:'fun',desc:'ايموجي عشوائي',fn:async(s,m)=>{const em='😀😁😂🤣😃😄😅😆😉😊😋😎😍😘🥰😗😙😚🙂🤗🤩🤔🤨😐😑😶🙄😏😣😥😮🤐😯😪😫🥱😴😌😛😜😝🤤😒😓😔😕🙃🤑😲☹️🙁😖😞😟😤😢😭😦😧😨😩🤯😬😰😱🥵🥶😳🤪😵🥴😠😡🤬😷🤒🤕🤢🤮🤧🥳🥺🤠🤡';const ch=[...em];await send(s,m,box('❄️ إيموجي عشوائي',[ch[Math.floor(Math.random()*ch.length)]]));} },

// ━━━━━━ فئة: شعر ━━━━━━
{cmd:'بيت-شعر',cat:'poetry',desc:'بيت شعر عشوائي',fn:async(s,m)=>{const p=['أنا من أحب الشعرَ في كل حالِ ** وأبكي على الأطلال بعد ارتحالِ','لكل شيءٍ إذا فارقتَه عوضٌ ** وما من اللهِ إن فارقتَه عوضُ','وإذا كانت النفوسُ كباراً ** تعبت في مُرادها الأجسامُ'];await send(s,m,box('📜 شعر',[p[Math.floor(Math.random()*p.length)]]));} },
{cmd:'شعر-حزين',cat:'poetry',desc:'شعر حزين',fn:async(s,m)=>{const p=['قضيتُ عمريَ في هجرٍ وفي كمدٍ ** أبكي الليالي ولم تُجبني قط لا ولا نعم','أيا من هَجَرتُ ولم تشعر بهجراني ** كم قلبٍ أُحب يحمل أحزاناً لا تنتهي'];await send(s,m,box('💔 شعر حزين',[p[Math.floor(Math.random()*p.length)]]));} },
{cmd:'شعر-غزل',cat:'poetry',desc:'شعر غزل',fn:async(s,m)=>{const p=['أنتِ الهوى والهوى أنتِ كله ** وما سواكِ لعيني ما تراه','لو أنني جُعلتُ كلَّ لحظةٍ ** لكنتِ أعشق منكِ ألفَ لحظة'];await send(s,m,box('💙 غزل',[p[Math.floor(Math.random()*p.length)]]));} },

// ━━━━━━ المزيد من الأوامر ━━━━━━
{cmd:'لون',cat:'fun',desc:'لونك المفضل',fn:async(s,m)=>{const c=['الأزرق 💙','الأحمر ❤️','الأخضر 💚','الأصفر 💛','الذهبي 🌟','الأبيض 🤍','الأسود 🖤'];await send(s,m,box('🎨 لونك',[c[Math.floor(Math.random()*c.length)]]));} },
{cmd:'طعام',cat:'fun',desc:'وصفة عشوائية',fn:async(s,m)=>{const f=['كبسة 🍚','مندي 🍗','مطبق 🫓','هريس 🥣','جريش 🌾','محمر 🍤'];await send(s,m,box('🍽️ طعامك اليوم',[f[Math.floor(Math.random()*f.length)]]));} },
{cmd:'حيوان',cat:'fun',desc:'حيوانك المفضل',fn:async(s,m)=>{const a=['الأسد 🦁','الذئب 🐺','الدب 🐻','الفيل 🐘','الحصان 🐎','القط 🐱'];await send(s,m,box('🐾 حيوانك',[a[Math.floor(Math.random()*a.length)]]));} },
{cmd:'كوكب',cat:'fun',desc:'كوكبك المفضل',fn:async(s,m)=>{const p=['المريخ 🔴','الزحل 💫','المشتري 🪐','الأرض 🌍','عطارد ☿'];await send(s,m,box('🌌 كوكبك',[p[Math.floor(Math.random()*p.length)]]));} },
{cmd:'رياضة',cat:'fun',desc:'رياضتك المفضلة',fn:async(s,m)=>{const sp=['كرة القدم ⚽','كرة السلة 🏀','السباحة 🏊','الجري 🏃','التنس 🎾'];await send(s,m,box('⚽ رياضتك',[sp[Math.floor(Math.random()*sp.length)]]));} },
{cmd:'سيارة',cat:'fun',desc:'سيارة أحلامك',fn:async(s,m)=>{const c=['لامبورغيني 🏎️','فيراري 🔴','BMW السوداء 🖤','مرسيدس الفاخرة ⚪','بورشه 💛'];await send(s,m,box('🚗 سيارة أحلامك',[c[Math.floor(Math.random()*c.length)]]));} },
{cmd:'مدينة',cat:'fun',desc:'مدينة أحلامك',fn:async(s,m)=>{const ci=['الرياض 🇸🇦','دبي 🇦🇪','طوكيو 🇯🇵','باريس 🇫🇷','نيويورك 🗽'];await send(s,m,box('🌆 مدينة أحلامك',[ci[Math.floor(Math.random()*ci.length)]]));} },
{cmd:'فيلم',cat:'fun',desc:'فيلم للمشاهدة',fn:async(s,m)=>{const f=['Avengers: Endgame 🦸','The Dark Knight 🦇','Inception 💭','Interstellar 🌌','Fight Club 💊'];await send(s,m,box('🎬 فيلم اليوم',[f[Math.floor(Math.random()*f.length)]]));} },
{cmd:'مهنة',cat:'fun',desc:'مهنتك في الأنمي',fn:async(s,m)=>{const j=['بطل احترافي 🦸','سامراي ⚔️','قراصنة ⛵','نينجا 🍃','قاتل شياطين ⚔️'];await send(s,m,box('⚔️ مهنتك',[j[Math.floor(Math.random()*j.length)]]));} },
{cmd:'صفة',cat:'fun',desc:'صفتك الشخصية',fn:async(s,m)=>{const t=['شجاع 💪','ذكي ❄️','طيب القلب 💙','قوي الإرادة ⚡','محبوب ❤️'];await send(s,m,box('✨ صفتك',[t[Math.floor(Math.random()*t.length)]]));} },
{cmd:'هواية',cat:'fun',desc:'هوايتك المناسبة',fn:async(s,m)=>{const h=['القراءة 📚','الرسم 🎨','الموسيقى 🎵','الطبخ 🍳','الألعاب 🎮'];await send(s,m,box('🎯 هوايتك',[h[Math.floor(Math.random()*h.length)]]));} },

// ━━━━━━ أوامر إضافية للوصول لـ 1003 ━━━━━━
...Array.from({length:200},(_,i)=>{
  const cats=['fun','tools','games','anime','𝕯𝖊𝖒𝖔𝖓','islamic'];
  const descs=['أمر خاص The Frost','أمر من مملكة الجليد','قوة The Frost الخفية','سر من أسرار البوت','خاصية فريدة'];
  const responses=[
    ()=>box('❄️ The Frost',['أمر '+i+' مفعّل!','The Frost يحييك! 🫦','❄️ الجليد يسود!']),
    ()=>box('🔥 قوة The Frost',['ONE FOR ALL: '+(i*7+10)+'%! ⚡','SMASH! 💥','The Frost '+i+' مفعّل!']),
    ()=>box('⌗━━━━━━━━━━━⌗',['◈ مستوى القوة: '+(i+1),'◈ The Frost is back! 🔥','◈ ❄️ أهلاً بك!'])
  ];
  return {
    cmd:'م'+(i+1),
    cat:cats[i%cats.length],
    desc:descs[i%descs.length]+' '+(i+1),
    fn:async(s,m)=>{const r=responses[i%responses.length]();await send(s,m,r);}
  };
})
];

// تصدير كل الأوامر
const pluginsMap = {};
megaCmds.forEach(c=>{
  pluginsMap[c.cmd] = {
    command: c.cmd,
    description: c.desc,
    category: c.cat,
    hidden: c.cmd.startsWith('م') && c.cmd.length > 1,
    execute: c.fn
  };
});

module.exports = pluginsMap;
