const fetch = require("node-fetch");
const sharp = require("sharp");

module.exports = {
  command: "قي",
  description: "فلتر قوس قزح على صورة البروفايل",
  usage: ".الوان @user",
  category: "ترفيه",

  async execute(sock, msg) {
    try {
      const jid = msg.key.remoteJid;

      const mentions =
        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

      if (!mentions.length) {
        return sock.sendMessage(jid, {
          text: "منشن شخص عشان أحط له فلتر قوس قزح 🌈"
        }, { quoted: msg });
      }

      const target = mentions[0];

      let pfp;
      try {
        pfp = await sock.profilePictureUrl(target, "image");
      } catch {
        return sock.sendMessage(jid, {
          text: "ما قدرت أجيب صورة البروفايل 😢"
        }, { quoted: msg });
      }

      const imgBuffer = await (await fetch(pfp)).buffer();

      // طبقة قوس قزح شفافة
      const width = 512;
      const height = 512;

      const rainbow = Buffer.from(
        `<svg width="${width}" height="${height}">
          <defs>
            <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="red"/>
              <stop offset="20%" stop-color="orange"/>
              <stop offset="40%" stop-color="yellow"/>
              <stop offset="60%" stop-color="green"/>
              <stop offset="80%" stop-color="blue"/>
              <stop offset="100%" stop-color="purple"/>
            </linearGradient>
          </defs>
          <rect width="100%" height="100%" fill="url(#g)" opacity="0.35"/>
        </svg>`
      );

      const result = await sharp(imgBuffer)
        .resize(512, 512)
        .composite([
          {
            input: rainbow,
            blend: "overlay"
          }
        ])
        .png()
        .toBuffer();

      await sock.sendMessage(jid, {
        image: result,
        caption: `🌈 تم تطبيق فلتر قوس قزح على @${target.split("@")[0]}`,
        mentions: [target]
      }, { quoted: msg });

    } catch (err) {
      console.error(err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: "صار خطأ في فلتر الألوان 🌈"
      }, { quoted: msg });
    }
  }
};